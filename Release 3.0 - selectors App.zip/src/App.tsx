import { useState } from "react"
import Select from "./Select"
import { SelectOption } from "./Select.tsx"
 const options=[
  {label:"First", value:1},
  {label:"Second", value:2},
  {label:"Third", value:3},
  {label:"Fourth", value:4},
  {label:"Fifth", value:5}
 ]

function App() {


  const[value1,setValue1] = useState<SelectOption|undefined>(options[0])
  const[value2,setValue2] = useState<SelectOption|undefined>([options[0]])
  return (
    <>
    <Select options={options} value = {value1} onChange={input1=>setValue1(input1)}/>
    <br />
    <Select  multiple ={true} options={options} value = {value2} onChange={input2=>setValue2(input2)}/>
    </>
  )
}

export default App
