
import { useEffect, useRef, useState } from 'react'
import styles from './select.module.css'

export type SelectOption={
    label:string,
    value:number|string 
}

type SingleSelectProps={
  multiple?:false
  value?:SelectOption
  onChange:(value:SelectOption|undefined)=>void
}
type MultiSelectProps={
  multiple:true
  value:SelectOption[]
  onChange:(value:SelectOption[])=>void
}
type SelectProps={
  options:SelectOption[]
} & (SingleSelectProps | MultiSelectProps)

const Select = ({multiple,value,options,onChange}:SelectProps) => {
const [isOpen,setIsOpen] = useState(false);
const [isHighLight,setIsHighLight] = useState(0);

const clearOptions = ()=>{
  if(multiple)onChange([])
  else onChange(undefined);
}

const selectOption=(option:SelectOption)=>{
  if(multiple){
    if(value.includes(option)){
      //include ho rkha hai to hta do 
      onChange(value.filter(o=>o!==option))
    }
    else{
      onChange([...value,option])
    }
  }
  else{
    if(option!==value)
    onChange(option)
  }
  
}

const isSelected=(option:SelectOption)=>{
  if(multiple){
      return value.includes(option)
  }
  else
    return option === value;
}

const containerRef = useRef<HTMLDivElement |undefined>()

useEffect(()=>{
if(isOpen)setIsHighLight(0);
},[isOpen])



useEffect(()=>{

  const handler =(e)=>{
    if(e.target!== containerRef.current)return;
  
    switch(e.code){
      case "Enter":
        case "Space":
          setIsOpen(prev=>!prev)
           if(isOpen)
           selectOption(options[isHighLight])
          break;
          case "ArrowDown":
            case "ArrowUp":{

              if(!isOpen){
                setIsOpen(true);
                break;
              }
              const newValue = isHighLight + (e.code === "ArrowDown"? 1: -1)
              if(newValue>=0 && newValue<options.length)
              setIsHighLight(newValue)
            }
            break;

            case "Escape":
            setIsOpen(false);
            break;
    }
  }
  
  containerRef.current?.addEventListener("keydown",handler);

  return ()=>{
    containerRef.current?.removeEventListener("keydown",handler);
  }
},[isHighLight,isOpen])

  return (
    <div 
    ref={containerRef}
    className={styles.container} 
    onClick={()=>setIsOpen(e=>!e)} 
    onBlur={()=>setIsOpen(false)}
    tabIndex={0}
    >
         
        <span className={styles.value}>


              {multiple?value.map(opt=>(
              <button 
              className={styles['option-badge']}
              key={opt.value}
              onClick={
                (e)=>{
                  e.stopPropagation();
                  selectOption(opt)
                }
              }
              >{opt.label}
              <span className={styles["remove-btn"]}>&times;</span>
              </button>

            )):value?.label}


        </span>

        <button className={styles['clear-btn']} onClick={(e)=>{
          e.stopPropagation();
          clearOptions();
        }}>&times;</button>

        <div className={styles.divider}></div>
        <div className={styles.caret}></div>


        <ul className={`${styles.options} ${isOpen?styles.show:""}`}>
            {options.map((option,index)=>
                <li 
                 
                onMouseEnter={()=>setIsHighLight(index)}
                   
                className={`
                ${styles.option} 
                ${isSelected(option)?styles.selected:""} 
                ${isHighLight === index?styles.highlighted:""}`}
                onClick={(e)=>{
                  e.stopPropagation();
                  selectOption(option)
                  setIsOpen(false)
                }} key={option.value}>{option.label}</li>
                )}
        </ul>


    </div>
  )
}

export default Select
